#Importing Libraries
import random
import pygame.mixer

#Initialize pygame mixer
pygame.mixer.init()

#Load background audio
pygame.mixer.music.load(r"Final Project\background_audio.mp3")  

#Set initial background audio state
audio_enabled = True

#Play background audi
pygame.mixer.music.play(-1)

# Function to toggle background audio
def toggle_audio():
    global audio_enabled
    if audio_enabled:
        pygame.mixer.music.pause()  
        print("Background audio turned OFF.")
    else:
        pygame.mixer.music.unpause()
        print("Background audio turned ON.")
    audio_enabled = not audio_enabled

# Function to show the game history
def show_game_history():
    print("\nshow Game History:")
    print("1 -> Multiplayer Game History")
    print("2 -> Versus Computer Game History")
    print("3 -> Back to Main Menu")
    choice = input("Enter a choice: ")

    if choice == '1':
        print("\nMultiplayer Game History:")
        if multiplayer_game_history:
            for game in multiplayer_game_history:
                print(game)
        else:
            print("No history available for Multiplayer Mode.")
    elif choice == '2':
        print("\nVersus Computer Game History:")
        if computer_game_history:
            for game in computer_game_history:
                print(game)
        else:
            print("No history available for Versus Computer Mode.")
    elif choice == '3':
        return
    else:
        print("Invalid choice.")


#Function to get player choice
def get_player_choice(player):
    while True:
        print(f"{player}, select an option:\n"
              + "1 -> Rock\n"
              + "2 -> Paper\n"
              + "3 -> Scissors\n"
              + "4 -> Quit")
        player_choice = input("Enter a choice: ")
        if player_choice in ['1', '2', '3', '4']:
            return player_choice
        else:
            print("Invalid choice. Please choose a valid option.")

#Function to Play Multiplayer
def play_multiplayer():
    global multiplayer_rounds_played, player1_score, player2_score

#Initialize game variables
player1_score = 0
player2_score = 0
multiplayer_rounds_played = 0

while True:
        player1_choice = get_player_choice("Player 1")

        if player1_choice == '4':
            break

        if player1_choice != '1' and player1_choice != '2' and player1_choice != '3':
            continue

        player2_choice = get_player_choice("Player 2")

        if player2_choice == '4':
            break

        if player2_choice != '1' and player2_choice != '2' and player2_choice != '3':
            continue

        # Determine the winner
        if player1_choice == player2_choice:
            result = "It's a tie!"
        elif (
            (player1_choice == "1" and player2_choice == "3")
            or (player1_choice == "2" and player2_choice == "1")
            or (player1_choice == "3" and player2_choice == "2")
        ):
            result = "Player 1 wins!"
            player1_score += 1
        else:
            result = "Player 2 wins!"
            player2_score += 1

        # Display the results and scores
        player1_choice_str = {"1": "rock", "2": "paper", "3": "scissors"}[player1_choice]
        player2_choice_str = {"1": "rock", "2": "paper", "3": "scissors"}[player2_choice]
        print(f"Player 1 chose {player1_choice_str}, and Player 2 chose {player2_choice_str}.")
        print(result)
        multiplayer_rounds_played += 1

        # Add the round result to the game history
        multiplayer_game_history = []
        multiplayer_game_history.append(f"Round {multiplayer_rounds_played}: Player 1 chose {player1_choice_str}, Player 2 chose {player2_choice_str}. {result}")

#Function to show multiplayer scoreboard
def show_multiplayer_scoreboard():
    print("\nMultiplayer Scoreboard:")
    print(f"Player 1: {player1_score}")
    print(f"Player 2: {player2_score}")
    print(f"Total Rounds: {multiplayer_rounds_played}\n")

show_multiplayer_scoreboard()

#Function to Play Computer
def play_computer():
    global computer_rounds_played, player_score, computer_score

#Initialize  game variables
player_score = 0
computer_score = 0
computer_rounds_played = 0

while True:
        player_choice = get_player_choice("Player")

        if player_choice == '4':
            break

        if player_choice not in ['1', '2', '3']:
            continue

        # Computer's choice
        computer_choice = random.choice(["rock", "paper", "scissors"])

        # Determine the winner
        if player_choice == computer_choice:
            result = "It's a tie!"
        elif (
            (player_choice == "1" and computer_choice == "scissors")
            or (player_choice == "2" and computer_choice == "rock")
            or (player_choice == "3" and computer_choice == "paper")
        ):
            result = "Player wins!"
            player_score += 1
        else:
            result = "Computer wins!"
            computer_score += 1

        # Display the results and scores
        player_choice_str = {"1": "rock", "2": "paper", "3": "scissors"}[player_choice]
        print(f"Player chose {player_choice_str}, and the computer chose {computer_choice}.")
        print(result)
        computer_rounds_played += 1

        # Add the round result to the game history
        computer_game_history = []
        computer_game_history.append(f"Round {computer_rounds_played}: Player chose {player_choice_str}, Computer chose {computer_choice}. {result}")

#Function to show computer scoreboard
def show_computer_scoreboard():
    print("\nVersus Computer Scoreboard:")
    print(f"Player: {player_score}")
    print(f"Computer: {computer_score}")
    print(f"Total Rounds: {rounds_played}\n")

show_computer_scoreboard()

#Main Menu
while True:
    print("Select a mode:\n"
          + "1 -> Multiplayer Mode\n"
          + "2 -> Versus Computer Mode\n"
          + "3 -> Toggle Background Audio\n"
          + "4 -> show Game History\n"
          + "5 -> Quit")
    
#Get user's choice
    mode_choice = input("Enter a choice: ")

# Check for valid input and execute selected mode or action
    if mode_choice == '5':
        break

    elif mode_choice == '1':
        play_multiplayer()
    elif mode_choice == '2':
        play_computer()
    elif mode_choice == '3':
        toggle_audio()
    elif mode_choice == '4':
         show_game_history()
    else:
        print("Invalid choice. Please choose a valid mode.")

# Game conclusion
print("Thanks for playing!")

# Determine the overall winner for each game mode
if player1_score > player2_score:
    print("Multiplayer Winner:", player1_score, "wins!")
elif player2_score > player1_score:
    print("Multiplayer Winner:", player2_score, "wins!")
else:
    print("Multiplayer: It's a tie!")

if player_score > computer_score:
    print("Versus Computer Winner:", player_score, "wins!")
elif computer_score > player_score:
    print("Versus Computer Winner:", computer_score, "wins!")
else:
    print("Versus Computer: It's a tie!")

# Asking whether to start a new game
while True:
    new_game = input("Do you want to start a new game in Multiplayer Mode? (yes/no): ").lower()
    if new_game == "yes":
        player1_score = 0
        player2_score = 0
        multiplayer_rounds_played = 0
        multiplayer_game_history = []
        break
    elif new_game == "no":
        break
    else:
        print("Invalid input. Please enter 'yes' or 'no'.")

while True:
    new_game = input("Do you want to start a new game in Versus Computer Mode? (yes/no): ").lower()
    if new_game == "yes":
        player_score = 0
        computer_score = 0
        rounds_played = 0
        computer_game_history = []
        break
    elif new_game == "no":
        print("Goodbye!")
        pygame.mixer.music.stop()
        break
    else:
        print("Invalid input. Please enter 'yes' or 'no'.")